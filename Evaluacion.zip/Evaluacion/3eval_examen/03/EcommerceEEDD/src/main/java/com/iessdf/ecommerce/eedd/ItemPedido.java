package com.iessdf.ecommerce.eedd;

public class ItemPedido {
    private int id;
    private Producto producto;
    private int cantidad;
    private double precio;
    private double total;

}
